import React, { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { socket } from "../socket"; // Import the socket instance

function Category() {
  const location = useLocation();
  const [eventType, setEventType] = useState();
  const [testData, setTestData] = useState([]);
  const [filteredData, setFilteredData] = useState([]);
  const queryParams = new URLSearchParams(location.search);
  let queryData = {};
  for (let [key, value] of queryParams) {
    queryData[key] = value;
  }

  const eventId = queryData["eventId"];
  const marketId = queryData["marketId"];
  useEffect(() => {
    

    const sampleEventDate = ['soccer', 'tennis', 'cricket'];

    let eventTypeValue;
    if (filteredData) {
      sampleEventDate.forEach((value, i) => {
        if (i === 0 && value === 'soccer') {
          eventTypeValue = 'soccer';
        } else if (i === 1 && value === 'cricket') {
          eventTypeValue = 'cricket';
        } else if (i === 2 && value === 'tennis') {
          eventTypeValue = 'tennis';
        }
      });
      setEventType(eventTypeValue);
    }
    const handleSocketData = (data) => {
      setTestData((prevTestData) => {
        const filteredData =
          marketId && eventId
            ? prevTestData.length > 0 &&
              prevTestData.filter(
                (item) =>
                  item.markets[0].marketId === parseInt(marketId, 10) &&
                  item.markets[0].eventId === parseInt(eventId, 10)
              )
            : prevTestData;
        setFilteredData(filteredData);
        return data; // Update the state with the new data
      });
    };
    
    

    socket.on('soccer', handleSocketData);

    return () => {
      // Cleanup the socket event listener when the component is unmounted
      socket.off(eventType, handleSocketData);
    };
  }, [location.search, eventType, marketId, eventId, testData, filteredData]);

  return (
    <div>
      <div>Category</div>
      <div>
        <div>{JSON.stringify(filteredData)}</div>
        {/* Display or use the eventData as needed */}
        <p>Data received from the server:</p>
      </div>
    </div>
  );
}

export default Category;
